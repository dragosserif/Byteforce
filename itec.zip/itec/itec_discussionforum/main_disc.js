const jobs = [
    {
      title: "Off-topic",
      image: "imagini/off.png",
      details:
        "Feel free to express your self. Here are no borders to limit you.",
      openPositions: "2",
      link: "#",
    },
  
    {
      title: "Gadgets and Electronics",
      image: "imagini/gag.png",
      details:
        "Speak with other people that are into tech.",
      openPositions: "3",
      link: "#",
    },
  
    {
      title: "Health and Fitness",
      image: "imagini/health.jpg",
      details:
        "Do you enjoy doing any type of physical exercise? Here you can chat with other sporty people.",
      openPositions: "1",
      link: "#",
    },
  
    {
      title: "Travel",
      image: "imagini/travel.jpg",
      details:
        "Looking for new places to vist? You can speak with are people that are into travelling.",
      openPositions: "1",
      link: "#",
    },
  
    {
      title: "Learning a foreign language",
      image: "imagini/lan.jpg",
      details:
        "Keen on learning a new language? Speak with other people that already know it",
      openPositions: "4",
      link: "#",
    },

  ];
  
  const jobsHeading = document.querySelector(".jobs-list-container h2");
  const jobsContainer = document.querySelector(".jobs-list-container .jobs");
  const jobSearch = document.querySelector(".jobs-list-container .job-search");
  
  let searchTerm = "";
  
  if (jobs.length == 1) {
    jobsHeading.innerHTML = `${jobs.length} Forum`;
  } else {
    jobsHeading.innerHTML = `${jobs.length} Forums`;
  }
  
  const createJobListingCards = () => {
    jobsContainer.innerHTML = "";
  
    jobs.forEach((job) => {
      if (job.title.toLowerCase().includes(searchTerm.toLowerCase())) {
        let jobCard = document.createElement("div");
        jobCard.classList.add("job");
  
        let image = document.createElement("img");
        image.src = job.image;
  
        let title = document.createElement("h3");
        title.innerHTML = job.title;
        title.classList.add("job-title");
  
        let details = document.createElement("div");
        details.innerHTML = job.details;
        details.classList.add("details");
  
        let detailsBtn = document.createElement("a");
        detailsBtn.href = job.link;
        detailsBtn.innerHTML = "More Details";
        detailsBtn.classList.add("details-btn");
  
        let openPositions = document.createElement("span");
        openPositions.classList.add("open-positions");
  
        if (job.openPositions == 1) {
          openPositions.innerHTML = `${job.openPositions} live discussion`;
        } else {
          openPositions.innerHTML = `${job.openPositions} live discussions`;
        }
  
        jobCard.appendChild(image);
        jobCard.appendChild(title);
        jobCard.appendChild(details);
        jobCard.appendChild(detailsBtn);
        jobCard.appendChild(openPositions);
  
        jobsContainer.appendChild(jobCard);
      }
    });
  };
  
  createJobListingCards();
  
  jobSearch.addEventListener("input", (e) => {
    searchTerm = e.target.value;
  
    createJobListingCards();
  });
  