const jobs = [
    {
      title: "Cleaning Servicies",
      image: "imagini/cleaning.jpg",
      details:
        "Servicies, which can help you clean your home, garden, office, etc.",
      openPositions: "2",
      link: "https://ro.linkedin.com/jobs/software-engineer-jobs?position=1&pageNum=0",
    },
  
    {
      title: "Repair and Maintenance",
      image: "imagini/repair.jpg",
      details:
        "Servicies that will help you repair your utilities.",
      openPositions: "3",
      link: "https://ro.linkedin.com/jobs/search?keywords=Data%20Scientist&location=Romania&geoId=106670623&trk=public_jobs_jobs-search-bar_search-submit&position=1&pageNum=0",
    },
  
    {
      title: "Landscaping and Gardening",
      image: "imagini/landscaping.jpg",
      details:
        "Servicies, which can help you have a nice garden.",
      openPositions: "1",
      link: "https://ro.linkedin.com/jobs/project-manager-jobs?position=1&pageNum=0",
    },
  
    {
      title: "Legal Services",
      image: "imagini/legal.jpg",
      details:
        "If you are in some legal trouble this is the place you have been looking for.",
      openPositions: "1",
      link: "https://ro.linkedin.com/jobs/search?keywords=Product%20Manager&location=Romania&geoId=106670623&trk=public_jobs_jobs-search-bar_search-submit&position=1&pageNum=0",
    },
  
  ];
  
  const jobsHeading = document.querySelector(".jobs-list-container h2");
  const jobsContainer = document.querySelector(".jobs-list-container .jobs");
  const jobSearch = document.querySelector(".jobs-list-container .job-search");
  
  let searchTerm = "";
  
  if (jobs.length == 1) {
    jobsHeading.innerHTML = `${jobs.length} Service`;
  } else {
    jobsHeading.innerHTML = `${jobs.length} Services`;
  }
  
  const createJobListingCards = () => {
    jobsContainer.innerHTML = "";
  
    jobs.forEach((job) => {
      if (job.title.toLowerCase().includes(searchTerm.toLowerCase())) {
        let jobCard = document.createElement("div");
        jobCard.classList.add("job");
  
        let image = document.createElement("img");
        image.src = job.image;
  
        let title = document.createElement("h3");
        title.innerHTML = job.title;
        title.classList.add("job-title");
  
        let details = document.createElement("div");
        details.innerHTML = job.details;
        details.classList.add("details");
  
        let detailsBtn = document.createElement("a");
        detailsBtn.href = job.link;
        detailsBtn.target = "_blank";
        detailsBtn.innerHTML = "More Details";
        detailsBtn.classList.add("details-btn");
  
        let openPositions = document.createElement("span");
        openPositions.classList.add("open-positions");
  
        if (job.openPositions == 1) {
          openPositions.innerHTML = `${job.openPositions} current option`;
        } else {
          openPositions.innerHTML = `${job.openPositions} current options`;
        }
  
        jobCard.appendChild(image);
        jobCard.appendChild(title);
        jobCard.appendChild(details);
        jobCard.appendChild(detailsBtn);
        jobCard.appendChild(openPositions);
  
        jobsContainer.appendChild(jobCard);
      }
    });
  };
  
  createJobListingCards();
  
  jobSearch.addEventListener("input", (e) => {
    searchTerm = e.target.value;
  
    createJobListingCards();
  });
  