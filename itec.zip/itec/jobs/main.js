const jobs = [
    {
      title: "Software Engineer",
      image: "imagini/software-engineer.svg",
      details:
        "Responsible for designing, developing and maintaining software systems and applications.",
      openPositions: "2",
      link: "https://ro.linkedin.com/jobs/software-engineer-jobs?position=1&pageNum=0",
    },
  
    {
      title: "Data Scientist",
      image: "imagini/data-scientist.svg",
      details:
        "Responsible for collecting, analyzing and interpreting large data sets to help organizations make better decisions.",
      openPositions: "3",
      link: "https://ro.linkedin.com/jobs/search?keywords=Data%20Scientist&location=Romania&geoId=106670623&trk=public_jobs_jobs-search-bar_search-submit&position=1&pageNum=0",
    },
  
    {
      title: "Project Manager",
      image: "imagini/project-manager.svg",
      details:
        "Responsible for planning, executing and closing projects on time and within budget.",
      openPositions: "1",
      link: "https://ro.linkedin.com/jobs/project-manager-jobs?position=1&pageNum=0",
    },
  
    {
      title: "Product Manager",
      image: "imagini/product-manager.svg",
      details:
        "Responsible for managing the entire product life cycle, from ideation to launch and post-launch maintenance.",
      openPositions: "1",
      link: "https://ro.linkedin.com/jobs/search?keywords=Product%20Manager&location=Romania&geoId=106670623&trk=public_jobs_jobs-search-bar_search-submit&position=1&pageNum=0",
    },
  
    {
      title: "Sales Representative",
      image: "imagini/sales-representative.svg",
      details:
        "Responsible for reaching out to potential customers and closing sales deals.",
      openPositions: "4",
      link: "https://ro.linkedin.com/jobs/search?keywords=Sales%20Representative&location=Romania&geoId=106670623&trk=public_jobs_jobs-search-bar_search-submit&position=1&pageNum=0",
    },
  
    {
      title: "Marketing Manager",
      image: "imagini/marketing-manager.svg",
      details:
        "Responsible for creating and executing marketing strategies to promote a company or product.",
      openPositions: "1",
      link: "https://ro.linkedin.com/jobs/search?keywords=Marketing%20Manager&location=Romania&geoId=106670623&trk=public_jobs_jobs-search-bar_search-submit&position=1&pageNum=0",
    },
  ];
  
  const jobsHeading = document.querySelector(".jobs-list-container h2");
  const jobsContainer = document.querySelector(".jobs-list-container .jobs");
  const jobSearch = document.querySelector(".jobs-list-container .job-search");
  
  let searchTerm = "";
  
  if (jobs.length == 1) {
    jobsHeading.innerHTML = `${jobs.length} Job`;
  } else {
    jobsHeading.innerHTML = `${jobs.length} Jobs`;
  }
  
  const createJobListingCards = () => {
    jobsContainer.innerHTML = "";
  
    jobs.forEach((job) => {
      if (job.title.toLowerCase().includes(searchTerm.toLowerCase())) {
        let jobCard = document.createElement("div");
        jobCard.classList.add("job");
  
        let image = document.createElement("img");
        image.src = job.image;
  
        let title = document.createElement("h3");
        title.innerHTML = job.title;
        title.classList.add("job-title");
  
        let details = document.createElement("div");
        details.innerHTML = job.details;
        details.classList.add("details");
  
        let detailsBtn = document.createElement("a");
        detailsBtn.href = job.link;
        detailsBtn.target = "_blank";
        detailsBtn.innerHTML = "More Details";
        detailsBtn.classList.add("details-btn");
  
        let openPositions = document.createElement("span");
        openPositions.classList.add("open-positions");
  
        if (job.openPositions == 1) {
          openPositions.innerHTML = `${job.openPositions} open position`;
        } else {
          openPositions.innerHTML = `${job.openPositions} open positions`;
        }
  
        jobCard.appendChild(image);
        jobCard.appendChild(title);
        jobCard.appendChild(details);
        jobCard.appendChild(detailsBtn);
        jobCard.appendChild(openPositions);
  
        jobsContainer.appendChild(jobCard);
      }
    });
  };
  
  createJobListingCards();
  
  jobSearch.addEventListener("input", (e) => {
    searchTerm = e.target.value;
  
    createJobListingCards();
  });
  