const jobs = [
    {
      title: "Single-Family Homes",
      image: "imagini/single-family.jpeg",
      details:
        "Want a new hous for you and your family? This is the right spot.",
      openPositions: "2",
      link: "#",
    },
  
    {
      title: "Apartments",
      image: "imagini/apartments.jpg",
      details:
        "Want a new home with a nice view? Might as well consider buying an apartment.",
      openPositions: "3",
      link: "#",
    },
  
    {
      title: "Condominiums (Condos)",
      image: "imagini/condo.jpg",
      details:
        "Wanna buy a condo? Here are the best deals that you can fing online.",
      openPositions: "1",
      link: "#",
    },
  
    {
      title: "Townhouses",
      image: "imagini/townhouses.jpg",
      details:
        "Want a townhouse? Here are the best deals that you can fing anywhere.",
      openPositions: "1",
      link: "#",
    },
  
    {
      title: "Duplexes/Triplexes",
      image: "imagini/duplex.jpg",
      details:
        "Considering buying a new home? Maybe a dublex or a triplex is the answer for you.",
      openPositions: "4",
      link: "#",
    },
  
    {
      title: "Lofts",
      image: "imagini/lofts.jpg",
      details:
        "Looking for Loft? Here is a variety of choices for you.",
      openPositions: "1",
      link: "#",
    },

    {
        title: "Co-ops",
        image: "imagini/co-op.jpg",
        details:
          "A co-op is sometime the best solution. Here are the best deals on co-ops.",
        openPositions: "1",
        link: "#",
      },
  ];
  
  const jobsHeading = document.querySelector(".jobs-list-container h2");
  const jobsContainer = document.querySelector(".jobs-list-container .jobs");
  const jobSearch = document.querySelector(".jobs-list-container .job-search");
  
  let searchTerm = "";
  
  if (jobs.length == 1) {
    jobsHeading.innerHTML = `${jobs.length} Property`;
  } else {
    jobsHeading.innerHTML = `${jobs.length} Properties`;
  }
  
  const createJobListingCards = () => {
    jobsContainer.innerHTML = "";
  
    jobs.forEach((job) => {
      if (job.title.toLowerCase().includes(searchTerm.toLowerCase())) {
        let jobCard = document.createElement("div");
        jobCard.classList.add("job");
  
        let image = document.createElement("img");
        image.src = job.image;
  
        let title = document.createElement("h3");
        title.innerHTML = job.title;
        title.classList.add("job-title");
  
        let details = document.createElement("div");
        details.innerHTML = job.details;
        details.classList.add("details");
  
        let detailsBtn = document.createElement("a");
        detailsBtn.href = job.link;
        detailsBtn.innerHTML = "More Details";
        detailsBtn.classList.add("details-btn");
  
        let openPositions = document.createElement("span");
        openPositions.classList.add("open-positions");
  
        if (job.openPositions == 1) {
          openPositions.innerHTML = `${job.openPositions} Available Option`;
        } else {
          openPositions.innerHTML = `${job.openPositions} Available Options`;
        }
  
        jobCard.appendChild(image);
        jobCard.appendChild(title);
        jobCard.appendChild(details);
        jobCard.appendChild(detailsBtn);
        jobCard.appendChild(openPositions);
  
        jobsContainer.appendChild(jobCard);
      }
    });
  };
  
  createJobListingCards();
  
  jobSearch.addEventListener("input", (e) => {
    searchTerm = e.target.value;
  
    createJobListingCards();
  });
  