const jobs = [
    {
      title: "Mobile Phones and Tablets",
      image: "imagini/phones.jpg",
      details:
        "Want a new smart device? This is where you will find everythinh you need.",
      openPositions: "2",
      link: "https://ro.linkedin.com/jobs/software-engineer-jobs?position=1&pageNum=0",
    },
  
    {
      title: "Computers and Laptops",
      image: "imagini/laptop.jpg",
      details:
        "Shop for Computers and Laptops that just came on to the market.",
      openPositions: "3",
      link: "https://ro.linkedin.com/jobs/search?keywords=Data%20Scientist&location=Romania&geoId=106670623&trk=public_jobs_jobs-search-bar_search-submit&position=1&pageNum=0",
    },
  
    {
      title: "Audio and Video",
      image: "imagini/audio.jpeg",
      details:
        "Here you will find recording equipment.",
      openPositions: "1",
      link: "https://ro.linkedin.com/jobs/project-manager-jobs?position=1&pageNum=0",
    },
  
    {
      title: "Cars and Trucks",
      image: "imagini/cars.jpg",
      details:
        "Shoping for a new automotive? This is the best place where to look for.",
      openPositions: "1",
      link: "https://ro.linkedin.com/jobs/search?keywords=Product%20Manager&location=Romania&geoId=106670623&trk=public_jobs_jobs-search-bar_search-submit&position=1&pageNum=0",
    },
  
    {
      title: "Motorcycles and Scooters",
      image: "imagini/moto.jpg",
      details:
        "Want a new motorcycle or a scooter? You came where you should have.",
      openPositions: "4",
      link: "https://ro.linkedin.com/jobs/search?keywords=Sales%20Representative&location=Romania&geoId=106670623&trk=public_jobs_jobs-search-bar_search-submit&position=1&pageNum=0",
    },
  
    {
      title: "Furniture",
      image: "imagini/furnniture.jpg",
      details:
        "Want some new furniture for your home?This is the place.",
      openPositions: "1",
      link: "https://ro.linkedin.com/jobs/search?keywords=Marketing%20Manager&location=Romania&geoId=106670623&trk=public_jobs_jobs-search-bar_search-submit&position=1&pageNum=0",
    },

    {
        title: "Parts and Accessories",
        image: "imagini/acc.jpg",
        details:
          "Have a nice outfit but something seems off? Here you will find the best accesories.",
        openPositions: "2",
        link: "https://ro.linkedin.com/jobs/search?keywords=Marketing%20Manager&location=Romania&geoId=106670623&trk=public_jobs_jobs-search-bar_search-submit&position=1&pageNum=0",
      },

  ];
  
  const jobsHeading = document.querySelector(".jobs-list-container h2");
  const jobsContainer = document.querySelector(".jobs-list-container .jobs");
  const jobSearch = document.querySelector(".jobs-list-container .job-search");
  
  let searchTerm = "";
  
  if (jobs.length == 1) {
    jobsHeading.innerHTML = `${jobs.length} Post`;
  } else {
    jobsHeading.innerHTML = `${jobs.length} Posts`;
  }
  
  const createJobListingCards = () => {
    jobsContainer.innerHTML = "";
  
    jobs.forEach((job) => {
      if (job.title.toLowerCase().includes(searchTerm.toLowerCase())) {
        let jobCard = document.createElement("div");
        jobCard.classList.add("job");
  
        let image = document.createElement("img");
        image.src = job.image;
  
        let title = document.createElement("h3");
        title.innerHTML = job.title;
        title.classList.add("job-title");
  
        let details = document.createElement("div");
        details.innerHTML = job.details;
        details.classList.add("details");
  
        let detailsBtn = document.createElement("a");
        detailsBtn.href = job.link;
        detailsBtn.target = "_blank";
        detailsBtn.innerHTML = "More Details";
        detailsBtn.classList.add("details-btn");
  
        let openPositions = document.createElement("span");
        openPositions.classList.add("open-positions");
  
        if (job.openPositions == 1) {
          openPositions.innerHTML = `${job.openPositions} current option`;
        } else {
          openPositions.innerHTML = `${job.openPositions} current options`;
        }
  
        jobCard.appendChild(image);
        jobCard.appendChild(title);
        jobCard.appendChild(details);
        jobCard.appendChild(detailsBtn);
        jobCard.appendChild(openPositions);
  
        jobsContainer.appendChild(jobCard);
      }
    });
  };
  
  createJobListingCards();
  
  jobSearch.addEventListener("input", (e) => {
    searchTerm = e.target.value;
  
    createJobListingCards();
  });
  