const jobs = [
  {
    title: "Libraries and Community Centers",
    image: "imagini/library.jpg",
    details:
      "You are into reading. Consider the following community",
    openPositions: "2",
    link: "#",
  },

  {
    title: "Emergency Services",
    image: "imagini/emergency.jpg",
    details:
      "The perfect community for urgent situations.",
    openPositions: "3",
    link: "#",
  },

  {
    title: "Support Groups",
    image: "imagini/support.jpg",
    details:
      "Going thtough a difficult time? Consider joining this community.",
    openPositions: "1",
    link: "#",
  },

  {
    title: "Farmers' Markets",
    image: "imagini/farmer.jpg",
    details:
      "Perfect community for farmers and people that are into agriculture.",
    openPositions: "1",
    link: "#",
  },

  {
    title: "Charity Events",
    image: "imagini/charity.jpg",
    details:
      "Wanna do some charity? This community is going to help you do so.",
    openPositions: "4",
    link: "#",
  },

  {
    title: "Festivals and Fairs",
    image: "imagini/festival.jpg",
    details:
      "Are into partying and havinf fun? Then you must join this community.",
    openPositions: "1",
    link: "#",
  },

  {
      title: "Cooking Classes",
      image: "imagini/cooking.jpg",
      details:
        "Want to perfect your cooking. This is the palce to.",
      openPositions: "2",
      link: "#",
    },

    {
      title: "Art Workshops",
      image: "imagini/art.jpg",
      details:
        "This is the place for creative people.",
      openPositions: "1",
      link: "#",
    },

    {
      title: "Fitness and Wellness Workshops",
      image: "imagini/fitness.jpg",
      details:
        "If you are into physical activities then you must join this group.",
      openPositions: "3",
      link: "#",
    },
];

const jobsHeading = document.querySelector(".jobs-list-container h2");
const jobsContainer = document.querySelector(".jobs-list-container .jobs");
const jobSearch = document.querySelector(".jobs-list-container .job-search");

let searchTerm = "";

if (jobs.length == 1) {
  jobsHeading.innerHTML = `${jobs.length} Community`;
} else {
  jobsHeading.innerHTML = `${jobs.length} Communities`;
}

const createJobListingCards = () => {
  jobsContainer.innerHTML = "";

  jobs.forEach((job) => {
    if (job.title.toLowerCase().includes(searchTerm.toLowerCase())) {
      let jobCard = document.createElement("div");
      jobCard.classList.add("job");

      let image = document.createElement("img");
      image.src = job.image;

      let title = document.createElement("h3");
      title.innerHTML = job.title;
      title.classList.add("job-title");

      let details = document.createElement("div");
      details.innerHTML = job.details;
      details.classList.add("details");

      let detailsBtn = document.createElement("a");
      detailsBtn.href = job.link;
      detailsBtn.innerHTML = "More Details";
      detailsBtn.classList.add("details-btn");

      let openPositions = document.createElement("span");
      openPositions.classList.add("open-positions");

      if (job.openPositions == 1) {
        openPositions.innerHTML = `${job.openPositions} live group`;
      } else {
        openPositions.innerHTML = `${job.openPositions} live groups`;
      }

      jobCard.appendChild(image);
      jobCard.appendChild(title);
      jobCard.appendChild(details);
      jobCard.appendChild(detailsBtn);
      jobCard.appendChild(openPositions);

      jobsContainer.appendChild(jobCard);
    }
  });
};

createJobListingCards();

jobSearch.addEventListener("input", (e) => {
  searchTerm = e.target.value;

  createJobListingCards();
});
