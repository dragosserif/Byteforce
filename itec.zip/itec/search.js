const elem = document.getElementById("searchbar");
const lupa = document.getElementById("lupa");

elem.addEventListener('focus',dispare);
elem.addEventListener('blur',apare);

function dispare() {
    lupa.style.visibility='hidden';
}
function apare() {
    lupa.style.visibility='visible';
}